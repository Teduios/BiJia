//
//  WRTextFieldTool.h
//  比价
//
//  Created by apple-jd28 on 15/11/25.
//  Copyright © 2015年 apple-jd28. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WRTextFieldTool : NSObject

+ (void)addHideDowmItemAtTFKeyboard:(UITextField*)tf;

@end
