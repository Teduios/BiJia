//
//  WRHistory.h
//  比价
//
//  Created by apple-jd28 on 15/11/24.
//  Copyright © 2015年 apple-jd28. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WRHistory : NSObject <NSCoding>

/** 历史记录数组 */
@property (nonatomic, strong) NSArray *historyArr;

@end
