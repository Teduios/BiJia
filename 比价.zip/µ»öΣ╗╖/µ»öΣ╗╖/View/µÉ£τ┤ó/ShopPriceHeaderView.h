//
//  ShopPriceHeaderView.h
//  比价
//
//  Created by apple-jd28 on 15/11/17.
//  Copyright © 2015年 apple-jd28. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SearchDetailDataModel;
@interface ShopPriceHeaderView : UIView

@property (nonatomic, strong) SearchDetailDataModel *dataModel;

@end
