






//
//  ProfileCollectModel.m
//  比价
//
//  Created by apple-jd28 on 15/11/23.
//  Copyright © 2015年 apple-jd28. All rights reserved.
//

#import "ProfileCollectModel.h"

@implementation ProfileCollectModel

+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [ProfileCollectDataModel class]};
}

@end

@implementation ProfileCollectDataModel


@end

@implementation ProfileCollectDataBmobModel

- (NSString *)goodPrice
{
    
    return [NSString stringWithFormat:@"%@",_goodPrice];

}

@end