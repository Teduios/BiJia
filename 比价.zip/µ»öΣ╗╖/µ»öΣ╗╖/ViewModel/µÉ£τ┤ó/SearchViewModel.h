//
//  SearchViewModel.h
//  比价
//
//  Created by apple-jd28 on 15/11/13.
//  Copyright © 2015年 apple-jd28. All rights reserved.
//

#import "BaseViewModel.h"
#import "ShopModel.h"

@interface SearchViewModel : BaseViewModel

@property (nonatomic, strong) NSString *textStr;

@end
